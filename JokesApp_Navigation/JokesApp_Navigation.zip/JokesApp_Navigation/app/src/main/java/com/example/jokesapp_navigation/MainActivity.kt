package com.example.jokesapp_navigation

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.jokesapp_navigation.ui.theme.JokesApp_NavigationTheme
import com.example.jokesapp_navigation.ui.theme.pages.CreateJokePage
import com.example.jokesapp_navigation.ui.theme.pages.JokesPage
import com.example.jokesapp_navigation.ui.theme.pages.LoginPage

class MainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterialScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JokesApp_NavigationTheme {

                Scaffold(

                    topBar = {

                        TopAppBar() {

                            Text(modifier = Modifier.padding(4.dp), text = "My App")

                        }

                    },
                    bottomBar = {

                        BottomNavigation {

                            BottomNavigationItem(selected = false, onClick = { /*TODO*/ }, icon = { Icon(imageVector = Icons.Filled.Home, contentDescription = "Home Icon") })
                            BottomNavigationItem(selected = false, onClick = { /*TODO*/ }, icon = { Icon(imageVector = Icons.Filled.Menu, contentDescription = "Menu Icon") })
                            BottomNavigationItem(selected = false, onClick = { /*TODO*/ }, icon = { Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Icon") })

                        }
                    }
                ){

                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colors.background
                    ) {

                        MyApp()

                    }

                }


            }
        }
    }
}

@Composable
fun MyApp(){

    val navHostController = rememberNavController()

    NavHost(navController = navHostController, startDestination = "login"){

        composable( route = "login" ){

            LoginPage(navController = navHostController)

        }

        composable( route = "jokesPage/{uname}/{pw}" ){

            var username = it.arguments?.getString("uname")
            var password = it.arguments?.getString("pw")

            if(username == null) username = "nobody"
            if(password == null) password = "nothing"
            if(username != null && password != null){

                JokesPage(navController = navHostController, username, password)

            }

        }

        composable( route = "createJokePage" ){

            CreateJokePage(navController = navHostController)

        }

    }

}