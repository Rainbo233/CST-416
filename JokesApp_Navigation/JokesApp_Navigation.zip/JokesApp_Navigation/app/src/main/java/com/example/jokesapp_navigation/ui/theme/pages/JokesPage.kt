package com.example.jokesapp_navigation.ui.theme.pages

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun JokesPage(navController: NavHostController, username: String, password: String) {

    Column(modifier = Modifier.padding(20.dp)) {

        Text("Jokes Page")
        Text("Your username = $username. Pass = $password")
        Button(onClick = {

            navController.navigate("createJokePage")

        }) {

            Text(text = "Go to Add a Joke page (p3)")

        }

    }

}