package com.example.jokesapp_navigation.ui.theme.pages

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

@Composable
fun CreateJokePage(navController: NavHostController) {

    val question = remember { mutableStateOf("") }
    val answer = remember { mutableStateOf("") }
    val buttonEnabled = remember { mutableStateOf(true) }

    Surface(modifier = Modifier.padding(20.dp)) {

        Column() {

            Text("Create a Joke Page")
            OutlinedTextField(
                value = question.value,
                onValueChange = {

                        data -> question.value = data
                    buttonEnabled.value = !(answer.value == "" || question.value == "")

                },
                label = { Text("Question") }
            )

            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = answer.value,
                onValueChange = {

                        data -> answer.value = data
                    buttonEnabled.value = !(answer.value == "" || question.value == "")

                },
                label = { Text("Answer") }
            )

            Spacer(modifier = Modifier.height(10.dp))
            Button(

                onClick = {

                    Log.d("JokesPage", "question = ${question.value} answer = ${answer.value}")

                },
                enabled = buttonEnabled.value

            ) {

                Text(text = "Submit")

            }

        }

    }

}