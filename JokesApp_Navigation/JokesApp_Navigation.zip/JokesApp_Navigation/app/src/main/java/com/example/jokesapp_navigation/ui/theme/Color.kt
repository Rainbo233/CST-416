package com.example.jokesapp_navigation.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val SaddleBrown = Color(0xFF631D17)
val FireBrick = Color(0xFFa83E1B)
val GoldenRod = Color(0xFFE8C238)
val ForestGreen = Color(0xFF2CA128)
val ForestDarkGreen = Color(0xFF1D641C)