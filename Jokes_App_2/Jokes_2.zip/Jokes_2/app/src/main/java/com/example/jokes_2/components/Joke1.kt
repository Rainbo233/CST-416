package com.example.jokes_2.components

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em

@Composable
fun joke_1(joke: com.example.jokes_2.data.JokeModel, changeVisability: (id: Int) -> Unit) {

    Column() {

        Text(modifier = Modifier.padding(10.dp),
            text = "Joke number: ${joke.id}")

        Text(
            modifier = Modifier
                .padding(10.dp)
                .clickable {
                    changeVisability(joke.id)
                    Log.d("Joke Tag", "joke_1: $joke")
                },
            fontSize = 6.em,
            textAlign = TextAlign.Center,
            text = joke.question
        )

        if(joke.answer_is_visible){

            Text(
                modifier = Modifier
                    .padding(10.dp)
                    .background(Color.Gray)
                    .fillMaxWidth(),
                color = Color.White,
                fontSize = 5.em,
                text = joke.punch_line
            )

        }

        Divider()

    }
}