package com.example.jokes_2.data

data class JokeModel(

    val id: Int,
    var question: String,
    var punch_line: String,
    var answer_is_visible: Boolean

)