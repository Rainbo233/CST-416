package com.example.jokes_2.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.jokes_2.data.JokeModel

@Composable
fun joke_2(joke: JokeModel, context: Context){

    Text(

        text = joke.question,
        Modifier
            .padding(20.dp)
            .clickable{

                Toast
                    .makeText(context, joke.punch_line, Toast.LENGTH_LONG)
                    .show()

            }

    )

    Divider()

}