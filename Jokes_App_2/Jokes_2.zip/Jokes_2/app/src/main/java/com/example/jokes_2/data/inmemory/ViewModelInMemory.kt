package com.example.jokes_2.data.inmemory

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.example.jokes_2.data.JokeModel
import com.example.jokes_2.data.JokesViewModelInterface

class ViewModelInMemory : JokesViewModelInterface, ViewModel() {

    override var jokesList: MutableList<JokeModel> = mutableStateListOf<JokeModel>()
    override var jokesSearchResult: MutableList<JokeModel> = mutableStateListOf<JokeModel>()

    init {

        Log.d("JokeDataSource", "INIT is called")

        jokesList.add(

            JokeModel(

                0,
                "Why did the Chicken cross the road?",
                "To get to the other side!",
                true

            )

        )

        jokesList.add(

            JokeModel(

                1,
                "What's the difference between stupid and Texas?",
                "There is no difference!",
                true

            )

        )

        jokesList.add(

            JokeModel(

                2,
                "Elon Musk.",
                "That's it. He's the joke.",
                false

            )

        )

        jokesList.add(

            JokeModel(

                3,
                "Why was 6 afraid of 7?",
                "Because 7 ate 9.",
                true

            )

        )

        jokesList.add(

            JokeModel(

                4,
                "Knock, knock!",
                "On second thought doing this in text isn't gonna work.",
                false

            )

        )

    }

    override fun getAllJokes() {
        TODO("Not yet implemented")
    }

    override fun addJoke(joke: JokeModel) {
        jokesList.add(joke)
    }

    override fun removeJoke(joke: JokeModel) {
        jokesList.remove(joke)
    }

    override fun findJokesByKeyword(keyword: String) {

        jokesSearchResult.clear()

        for (joke in jokesList){

            if(joke.question.lowercase().contains(keyword) || joke.punch_line.lowercase().contains(keyword)){

                jokesSearchResult.add(joke)

            }


        }

    }

    override fun hideShowJoke(joke: JokeModel) {

        for(joke in jokesList){

            joke.answer_is_visible = false

        }

        var position : Int = jokesList.indexOf(joke)

        if(position >= 0){

            jokesList[position] = jokesList[position].copy(answer_is_visible = true)

        }

        for(joke in jokesSearchResult){

            joke.answer_is_visible = false

        }

        var position2 : Int = jokesSearchResult.indexOf(joke)

        if(position2 >= 0){

            jokesSearchResult[position2] = jokesSearchResult[position2].copy(answer_is_visible = true)

        }

    }
}