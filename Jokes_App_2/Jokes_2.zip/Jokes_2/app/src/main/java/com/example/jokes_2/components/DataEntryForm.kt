package com.example.jokes_2.components

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import com.example.jokes_2.data.JokeModel

@Composable
fun DataEntryForm(doAddJoke: (JokeModel) -> JokeModel) {

    Column() {

        val TEXTBOXPADDING = 5.dp

        var textBoxState by remember {

            mutableStateOf("")

        }

        val focusManager = LocalFocusManager.current

        var answerTextBoxState by remember {

            mutableStateOf("")

        }

        OutlinedTextField(
            value = textBoxState,
            onValueChange = { it ->

                Log.d("Allen", "Contents of Text Box: $it")
                textBoxState = it

            },
            modifier = Modifier
                .padding(TEXTBOXPADDING)
                .fillMaxWidth()
                .onKeyEvent {

                    Log.d("Allen", "OnKeyEvent $it")
                    if (it.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_ENTER) {

                        focusManager.clearFocus()

                    }
                    if (it.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_TAB) {

                        focusManager.moveFocus(FocusDirection.Down)

                    }
                    true


                },
            leadingIcon = {

                 IconButton(onClick = { /*TODO*/ }) {
//
                     Icon(

                         imageVector = Icons.Filled.Favorite,
                         contentDescription = "Icon"

                     )

                 }

            },
            label = {

                Text(text = "Tell me a joke!")

            },
            singleLine = true,
            keyboardActions = KeyboardActions(

                onDone = {

                    Log.d("Allen", "DataEntryForm: Done")
                    focusManager.clearFocus()

                }

            )

        )
        OutlinedTextField(
            value = answerTextBoxState,
            onValueChange = {it ->

                answerTextBoxState = it

            },
            modifier = Modifier
                .padding(TEXTBOXPADDING)
                .fillMaxWidth()
                .onKeyEvent {

                    if (it.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_ENTER) {

                        focusManager.clearFocus()
                        Log.d("add joke", "DataEntryForm: create a new joke...")
                        doAddJoke(

                            JokeModel(

                                0,
                                question = textBoxState,
                                punch_line = answerTextBoxState,
                                true

                            )

                        )

                    }

                    if (it.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_TAB) {

                        focusManager.moveFocus(FocusDirection.Up)

                    }
                    true

                },
            leadingIcon = {

                 IconButton(onClick = { /*TODO*/ }) {
//
                     Icon(

                         imageVector = Icons.Filled.ThumbUp,
                         contentDescription = "Icon"

                     )

                 }

            },
            label = {

                Text(text = "Enter the answer to your joke")

            },
            singleLine = true,
            keyboardActions = KeyboardActions(

                onDone = {

                    focusManager.clearFocus()
                    doAddJoke(JokeModel(0, question = textBoxState, punch_line = answerTextBoxState, true))

                }

            )

        )

    }

}