package com.example.jokes_2

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.jokes_2.components.DataEntryForm
import com.example.jokes_2.components.SearchForm
import com.example.jokes_2.components.joke_1
import com.example.jokes_2.data.JokeModel
import com.example.jokes_2.data.inmemory.ViewModelInMemory
import com.example.jokes_2.ui.theme.Jokes_2Theme

class MainActivity : ComponentActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Jokes_2Theme {
                MyApp()
            }
        }
    }
    }

@Composable
fun MyApp(){

    val viewModel : ViewModelInMemory = ViewModelInMemory()

    MainScreen(

        jokesList = viewModel.jokesList,
        jokesSearchResult = viewModel.jokesSearchResult,
        doAddJoke = { viewModel.addJoke(it) },
        doSearch = { viewModel.findJokesByKeyword(it) },
        doShowHide = { viewModel.hideShowJoke(it) }

    )

}

@Composable
private fun MainScreen(

    jokesList: List<JokeModel>,
    jokesSearchResult: List<JokeModel>,
    doAddJoke: (JokeModel) -> Unit,
    doSearch: (String) -> Unit,
    doShowHide: (JokeModel) -> Unit

    ){
    Surface(

        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colors.background

    ){

        Column() {

            DataEntryForm(doAddJoke = doAddJoke as (JokeModel) -> JokeModel)
            SearchForm(doSearch = doSearch)
            LazyColumn(){

                if(jokesSearchResult.isNotEmpty()){

                    Log.d("Main", "MainScreen: search found ${jokesSearchResult.size} jokes.")
                    items(jokesSearchResult.size){index ->

                        joke_1(joke = jokesSearchResult[index]){

                            doShowHide(jokesSearchResult[index])

                        }

                    }

                }else{

                    Log.d("Main", "MainScreen show all ${jokesList.size} jokes")
                    items(jokesList.size){index ->


                        joke_1(joke = jokesList[index]){

                            doShowHide(jokesList[index])

                        }

                    }

                }

            }


        }

    }


}





