package com.example.jokes_2.data

interface JokesViewModelInterface {

    var jokesList : MutableList<JokeModel>
    var jokesSearchResult : MutableList<JokeModel>

    fun getAllJokes(  )

    fun addJoke(joke: JokeModel)

    fun removeJoke(joke: JokeModel)

    fun findJokesByKeyword(keyword: String)

    fun hideShowJoke(joke: JokeModel)

}