package com.example.jokesapp.components

import android.view.KeyEvent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.Icon
import androidx.compose.material.IconButton
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp

@Composable
fun SearchForm(doSearch: (String) -> Unit) {
    val TEXTBOXPADDING = 5.dp

    Column() {
        var textboxState by remember {
            mutableStateOf("")
        }

        var answerTextboxState by remember {
            mutableStateOf("")
        }

        val focusManager = LocalFocusManager.current

        OutlinedTextField(
            value = textboxState,
            onValueChange = { it ->
                textboxState = it
            },
            modifier = Modifier
                .padding(TEXTBOXPADDING)
                .fillMaxWidth()
                .onKeyEvent {
                    if (it.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_ENTER) {
                        focusManager.clearFocus()
                        doSearch(textboxState.trim())
                    }
                    if (it.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_TAB) {
                        focusManager.moveFocus(FocusDirection.Down)
                    }
                    true
                },
            leadingIcon = {
                IconButton(onClick = { /*TODO*/ }) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Icon"
                    )
                }
            },
            label = {
                Text(text = "Search a joke")
            },
            singleLine = true,
            keyboardActions = KeyboardActions(
                onDone = {
                    focusManager.clearFocus()
                    doSearch(textboxState.trim())
                }
            )
        )
    }
}