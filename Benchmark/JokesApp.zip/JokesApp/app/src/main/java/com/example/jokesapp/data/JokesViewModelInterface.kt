package com.example.jokesapp.data


interface JokesViewModelInterface {

    var jokesList: MutableList<JokesModel>

    var jokesSearchResult : MutableList<JokesModel>

    fun getAllJokes()

    fun addJoke(joke : JokesModel)

    fun removeJoke(joke : JokesModel)

    fun findJokesByKeyword(kw : String)

    fun hideShowJoke(joke : JokesModel)
}