package com.example.jokesapp.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.jokesapp.data.JokesModel

@Composable
fun Joke2 (joke: JokesModel, context: Context) {
    Text(
        text = joke.question,
        Modifier
            .padding(20.dp)
            .clickable {
                Toast
                    .makeText(context, joke.answer, Toast.LENGTH_LONG)
                    .show()
            }
    )
    Divider()
}