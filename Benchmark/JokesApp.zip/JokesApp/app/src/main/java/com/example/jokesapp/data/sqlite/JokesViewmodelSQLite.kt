package com.example.jokesapp.data.sqlite

import android.content.Context
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jokesapp.data.JokesModel
import com.example.jokesapp.data.JokesViewModelInterface
import kotlinx.coroutines.launch

class JokesViewModelSQLite(context: Context) : JokesViewModelInterface, ViewModel() {
    val jokesDao = JokesDaoSQLite(context, null)
    val repository = JokesRepositorySQL(jokesDao)

    override var jokesList: MutableList<JokesModel> = mutableStateListOf<JokesModel>()
    override var jokesSearchResult: MutableList<JokesModel> = mutableStateListOf<JokesModel>()

    init {
        Log.d("JokesViewModel", "Init is called")
        getAllJokes()
    }


    override fun getAllJokes() {
        viewModelScope.launch {
            jokesList.clear()
            jokesList.addAll( repository.getAll())
        }
    }

    override fun addJoke(joke: JokesModel) {
        viewModelScope.launch {
            repository.addOne( joke )
            jokesList.add( joke )
            if (jokesSearchResult.size > 0) {
                jokesSearchResult.add( joke )
            }
        }
    }

    override fun removeJoke(joke: JokesModel) {
        viewModelScope.launch {
            repository.deleteOne( joke )
            jokesList.remove( joke )
            jokesSearchResult.remove(joke)
        }
    }

    override fun findJokesByKeyword(kw: String) {
        viewModelScope.launch {
            var results = repository.findByKeyword(phrase = kw)
            jokesSearchResult.clear()
            jokesSearchResult.addAll(results)
        }
    }

    override fun hideShowJoke(joke: JokesModel) {
        for (j in jokesList) {
            j.answerIsVisible = false
        }
        var position : Int = jokesList.indexOf(joke)

        if (position >= 0) {
            jokesList[position] = jokesList[position].copy(answerIsVisible = true)
        }
        for (j in jokesSearchResult) {
            j.answerIsVisible = false
        }
        var position2: Int = jokesSearchResult.indexOf(joke)

        if (position2 >= 0) {
            jokesSearchResult[position2] = jokesSearchResult[position2].copy(answerIsVisible = true)
        }
    }

}