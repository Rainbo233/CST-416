package com.example.jokesapp.data.inmemory

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.text.toLowerCase
import androidx.lifecycle.ViewModel
import com.example.jokesapp.data.JokesModel
import com.example.jokesapp.data.JokesViewModelInterface

class ViewModelInMemory : JokesViewModelInterface, ViewModel() {
    override var jokesList: MutableList<JokesModel> = mutableStateListOf<JokesModel>()
    override var jokesSearchResult: MutableList<JokesModel> = mutableStateListOf<JokesModel>()

    init {
        jokesList.add(
            JokesModel(
                0,
                "What time is it when an elephant sits on your fence?",
                "Time to get a new fence!",
                true
            )
        )
        jokesList.add(
            JokesModel(
                1,
                "What is red and smells like blue paint?",
                "Blue paint!",
                false
            )
        )
        jokesList.add(
            JokesModel(
                2,
                "Why did the chicken cross the playground?",
                "To get to the other slide!",
                false
            )
        )
        jokesList.add(
            JokesModel(
                3,
                "What did the mother buffalo say to her child when leaving him at school?",
                "Bison!",
                false
            )
        )
    }

    override fun getAllJokes() {
        TODO("Not yet implemented")
    }

    override fun addJoke(joke: JokesModel) {
        jokesList.add(joke)
    }

    override fun removeJoke(joke: JokesModel) {
        jokesList.remove(joke)
    }

    override fun findJokesByKeyword(kw: String) {
        jokesSearchResult.clear()

        for (joke in jokesList) {
            if (joke.question.lowercase().contains(kw) || joke.answer.lowercase().contains(kw)) {
                jokesSearchResult.add(joke)
            }
        }
    }

    override fun hideShowJoke(joke: JokesModel) {
        for (j in jokesList) {
            j.answerIsVisible = false
        }

        var position : Int = jokesList.indexOf(joke)

        if (position >= 0) {
            jokesList[position] = jokesList[position].copy(answerIsVisible = true)
        }

        for (j in jokesSearchResult) {
            j.answerIsVisible = false
        }

        var position2 : Int = jokesSearchResult.indexOf(joke)

        if (position2 >= 0) {
            jokesSearchResult[position2] = jokesSearchResult[position2].copy(answerIsVisible = true)
        }
    }

}