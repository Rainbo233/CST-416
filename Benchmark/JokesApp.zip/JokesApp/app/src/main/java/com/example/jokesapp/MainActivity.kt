package com.example.jokesapp

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import com.example.jokesapp.components.DataEntryForm
import com.example.jokesapp.components.Joke1
import com.example.jokesapp.components.SearchForm
import com.example.jokesapp.data.JokesModel
import com.example.jokesapp.data.JokesViewModelInterface
import com.example.jokesapp.data.inmemory.ViewModelInMemory
import com.example.jokesapp.data.room.JokesViewModelWithRoom
import com.example.jokesapp.data.sqlite.JokesViewModelSQLite
import com.example.jokesapp.ui.theme.JokesAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JokesAppTheme {
                MyApp()
            }
        }
    }

    @Composable
    fun MyApp() {
        // val viewModel : ViewModelInMemory = ViewModelInMemory()

        // val viewModel: JokesViewModelSQLite = JokesViewModelSQLite(context = applicationContext)

        val viewModel: JokesViewModelWithRoom = JokesViewModelWithRoom(context = applicationContext)


        MainScreen(
            jokesList = viewModel.jokesList,
            jokesSearchResult = viewModel.jokesSearchResult,
            doAddJoke = { viewModel.addJoke(it) },
            doSearch = { viewModel.findJokesByKeyword(it) },
            doShowHide = { viewModel.hideShowJoke(it) }
        )
    }

    private @Composable
    fun MainScreen(
        jokesList : List<JokesModel>,
        jokesSearchResult : List<JokesModel>,
        doAddJoke : (JokesModel) -> Unit,
        doSearch : (String) -> Unit,
        doShowHide : (JokesModel) -> Unit
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colors.background
        ) {
            Column() {
                DataEntryForm(doAddJoke = doAddJoke as (JokesModel) -> JokesModel)
                SearchForm(doSearch = doSearch)
                LazyColumn() {
                    if (jokesSearchResult.size > 0) {
                        items(jokesSearchResult.size) { index ->
                            Joke1(
                                joke = jokesSearchResult[index]
                            ) {
                                doShowHide(jokesSearchResult[index])
                            }
                        }
                    }
                    else {
                        items(jokesList.size) { index ->
                            Joke1(
                                joke = jokesList[index]
                            ) {
                                doShowHide(jokesList[index])
                            }
                        }
                    }
                }
            }
        }
    }




}




