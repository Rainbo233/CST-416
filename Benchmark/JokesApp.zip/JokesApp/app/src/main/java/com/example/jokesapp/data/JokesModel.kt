package com.example.jokesapp.data

import com.example.jokesapp.data.room.JokeEntity

data class JokesModel (
    val id: Int,
    var question: String,
    var answer: String,
    var answerIsVisible: Boolean
)

fun JokesModel.toEntity(): JokeEntity {
    return JokeEntity(id, question, answer)
}