package com.example.jokesapp.data.sqlite

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.jokesapp.data.JokesModel

class JokesDaoSQLite(
    context: Context,
    factory: SQLiteDatabase.CursorFactory?,
    name: String = "jokes_db"
):
    SQLiteOpenHelper (context, name, factory,1) {
    val JOKES_TABLE: String = "jokes_table"
    val ID_COL: String = "id"
    val JOKE_QUESTION_COLUMN: String = "joke_question"
    val JOKE_ANSWER_COLUMN: String = "joke_answer"
    override fun onCreate(db: SQLiteDatabase) {
        val query = ("CREATE TABLE " + JOKES_TABLE + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                JOKE_QUESTION_COLUMN + " TEXT," +
                JOKE_ANSWER_COLUMN + " TEXT)"
                )
        db.execSQL(query)
        Log.d("jokesDBHelper", "Created new db")
    }

    override fun onUpgrade(db: SQLiteDatabase, p1: Int, p2: Int) {
        db.execSQL("DROP TABLE IF EXISTS $JOKES_TABLE")
        onCreate(db)
    }

    fun addOne (joke: JokesModel): JokesModel?{
        val dataPairs = ContentValues()
        dataPairs.put (JOKE_QUESTION_COLUMN, joke.question)
        dataPairs.put (JOKE_ANSWER_COLUMN, joke.answer)

        val db = this.writableDatabase
        db.version

        val result = db. insert (JOKES_TABLE, null, dataPairs)
        Log.d("jokesDAO", "Added new item to db")
        Log.d( "jokesDAO", result.toString())

        db.close()

        if (result > 0) {
            return joke
        }
        else {
            return null
        }
    }

    fun getAll(): List<JokesModel> {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM " + JOKES_TABLE, null)
        var results = arrayListOf<JokesModel>()
        while (!cursor.isAfterLast) {
            Log.d("jokesdbhelper", "getAll: Cursor position S{cursor.position}")
            try {
                var joke =
                    JokesModel(cursor.getInt(0), cursor.getString(1), cursor.getString(2), false)
                results.add(joke)
            } catch (e: Exception) {
                Log.d("jockesDBHelper", "Exception error: $e.message")
            }
            cursor.moveToNext()
        }
        db.close()
        return results
    }

    fun getWithSearch(searchTerm: String): List<JokesModel> {
        val db = this.readableDatabase

        val searchWithWild = "%" + searchTerm + "%"
        val cursor = db.rawQuery(
            "SELECT * FROM " + JOKES_TABLE + " WHERE " +
                    JOKE_QUESTION_COLUMN + " LIKE ? OR " +
                    JOKE_ANSWER_COLUMN + " LIKE ?",
            arrayOf(searchWithWild, searchWithWild)
        )
        var results = arrayListOf<JokesModel>()
        while (!cursor.isAfterLast) {
            try {
                var joke =
                    JokesModel(cursor.getInt(0), cursor.getString(1), cursor.getString(2), false)
                results.add(joke)
            } catch (e: Exception) {
                Log.d("jockesDAO", "Exception error: $e.message")
            }
            cursor.moveToNext()
        }
        db.close()
        return results
    }

    fun deleteById(id: Int): Boolean {
        val db = this.writableDatabase
        val cursor = db.rawQuery("DELETE FROM " + JOKES_TABLE + " WHERE "+ID_COL+ " = '" + id + "'", null)

        val success = cursor.moveToFirst()
        db.close()
        return success
    }



}