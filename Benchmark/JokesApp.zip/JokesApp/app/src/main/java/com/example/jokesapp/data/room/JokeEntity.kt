package com.example.jokesapp.data.room


import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.jokesapp.data.JokesModel

@Entity(tableName = "jokes_table")
data class JokeEntity(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name= "joke_id") val id: Int,
    @ColumnInfo (name = "joke_question") var question: String,
    @ColumnInfo (name = "joke_answer") var answer: String
)
fun JokeEntity.toModel(): JokesModel {
    return JokesModel(id, question, answer, false)
}