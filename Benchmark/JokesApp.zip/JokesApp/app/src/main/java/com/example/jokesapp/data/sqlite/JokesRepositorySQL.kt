package com.example.jokesapp.data.sqlite

import com.example.jokesapp.data.JokesModel

class JokesRepositorySQL(val jokeDao: JokesDaoSQLite) {
    suspend fun getAll() = jokeDao.getAll()
    suspend fun findByKeyword(phrase: String) = jokeDao.getWithSearch(phrase)
    suspend fun addOne (joke: JokesModel) = jokeDao.addOne(joke)
    suspend fun deleteOne(joke: JokesModel) = jokeDao.deleteById(joke.id)
}