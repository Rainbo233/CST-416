package com.example.jokesapp.data.room

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface JokeDaoRoom {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun addOne(joke: JokeEntity)

    @Delete
    fun removeJoke(joke: JokeEntity)

    @Query("SELECT * FROM jokes_table WHERE joke_id = :id")
    fun getById(id: Int): Flow<JokeEntity>

    @Query("SELECT * FROM jokes_table WHERE joke_question LIKE :findPhrase OR joke_answer LIKE :findPhrase")
    fun getWithSearch(findPhrase: String): Flow<List<JokeEntity>>

    @Query("SELECT * FROM jokes_table")
    fun getAll(): Flow<List<JokeEntity>>
}
