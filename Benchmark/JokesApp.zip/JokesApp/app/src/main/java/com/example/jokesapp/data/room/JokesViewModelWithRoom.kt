package com.example.jokesapp.data.room

import android.content.Context
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jokesapp.data.JokesModel
import com.example.jokesapp.data.JokesViewModelInterface
import com.example.jokesapp.data.toEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JokesViewModelWithRoom ( context: Context): JokesViewModelInterface, ViewModel() {
    val db = AppDatabase.getInstance(context)
    val jokeDao = db.jokeDao()
    var jokesRepository = JokesRepository(jokeDao)

    override var jokesList: MutableList<JokesModel> = mutableStateListOf<JokesModel>()
    override var jokesSearchResult: MutableList<JokesModel> = mutableStateListOf<JokesModel>()

    init {
        getAllJokes()
    }

    override fun getAllJokes() {
        viewModelScope.launch {
            jokesList.clear()
            jokeDao.getAll().collect() { response ->
                for (entity in response) {
                    jokesList.add(entity.toModel())
               }
            }
        }
    }

    override fun addJoke(joke: JokesModel) {
        viewModelScope.launch(Dispatchers.IO) {
            jokesRepository.addOne(joke.toEntity())
            jokesList.add(joke)
        }
    }

    override fun removeJoke(joke: JokesModel) {
        viewModelScope.launch(Dispatchers.IO) {
            jokesRepository.deleteOne(joke.toEntity())
        }
    }

    override fun findJokesByKeyword(kw: String) {
        viewModelScope.launch {
            jokesList.clear()
            jokesRepository.findByKeyword(kw).collect() { response ->
                for (entity in response) {
                    jokesList.add(entity.toModel())
                    Log.d(
                        "jokesviewmodel",
                        "findJokesByKeyword: found $entity and how have ${jokesList.size} jokes"
                    )
                }
            }
        }
    }

    override fun hideShowJoke(joke: JokesModel) {
        for (j in jokesList) {
            j.answerIsVisible = false
        }
        var position: Int = jokesList.indexOf(joke)
        if (position >= 0) {

        }

        if (position >= 0) {
            jokesList[position] = jokesList[position].copy(answerIsVisible = true)
        }
        for (j in jokesSearchResult) {
            j.answerIsVisible = false
        }
        var position2: Int = jokesSearchResult.indexOf(joke)

        if (position2 >= 0) {
            jokesSearchResult[position2] = jokesSearchResult[position2].copy(answerIsVisible = true)
        }

    }
}
